<?php
if(isset($_FILES['file'])) {
  $file = $_FILES['file'];

  // File details
  $fileName = $file['name'];
  $fileTmpName = $file['tmp_name'];
  $fileSize = $file['size'];
  $fileError = $file['error'];

  // Define the destination directory to save the uploaded file
  $destination = 'path/to/destination/' . $fileName;

  // Move the uploaded file to the destination directory
  if(move_uploaded_file($fileTmpName, $destination)) {
    // File uploaded successfully
    echo "File uploaded successfully.";
  } else {
    // Error occurred while uploading the file
    echo "Error uploading file.";
  }
}
?>
