<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['file'])) {
        $file = $_FILES['file'];
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileError = $file['error'];

        if ($fileError === UPLOAD_ERR_OK) {
            $destination = 'uploads/' . $fileName;
            move_uploaded_file($fileTmpName, $destination);
            echo "File uploaded successfully!";
        } else {
            echo "Error uploading file. Please try again.";
        }
    }
}
?>
